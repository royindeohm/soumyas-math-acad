import { useIntersectionObserver } from '@/hooks/useIntersectionObserver';
import { GraduationCap, BookOpen, FlaskConical, MapPin } from 'lucide-react';

const credentials = [
  { icon: GraduationCap, text: 'M.Sc in Mathematics' },
  { icon: BookOpen, text: 'Specialization: Applied Mathematics' },
  { icon: FlaskConical, text: 'Subjects: Mathematics, Physics, Chemistry' },
  { icon: MapPin, text: 'Mode: Offline Classes Only' },
];

export default function About() {
  const { ref: sectionRef, isInView } = useIntersectionObserver<HTMLElement>({
    threshold: 0.2,
  });

  return (
    <section
      id="about"
      ref={sectionRef}
      className="w-full py-[120px] md:py-[120px] bg-white"
    >
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-16 items-center">
          {/* Left: Text Content */}
          <div
            className={`w-full md:w-[45%] transition-all duration-700 ease-out ${
              isInView
                ? 'opacity-100 translate-x-0'
                : 'opacity-0 -translate-x-10'
            }`}
          >
            <p className="section-label mb-4">ABOUT THE EDUCATOR</p>
            <h2 className="heading-2 mb-6">Meet Soumyadip Biswas</h2>
            <p className="font-['Inter'] text-[18px] text-[#4a5568] leading-[1.7] mb-8">
              With a Master's degree in Mathematics and years of dedicated teaching
              experience, I specialize in making complex mathematical concepts simple
              and intuitive. My approach combines conceptual clarity with rigorous
              practice, ensuring every student builds a strong foundation. Located in
              Narayanpur, Kankinara, I provide personalized offline coaching for
              students from Class VI to XII across WB Board, ICSE, and CBSE curricula.
            </p>

            {/* Credentials */}
            <div className="flex flex-col gap-4">
              {credentials.map((cred, i) => (
                <div
                  key={i}
                  className={`flex items-center gap-4 transition-all duration-500 ease-out ${
                    isInView
                      ? 'opacity-100 translate-x-0'
                      : 'opacity-0 -translate-x-6'
                  }`}
                  style={{ transitionDelay: `${0.3 + i * 0.1}s` }}
                >
                  <div className="w-10 h-10 rounded-lg bg-[#dbeafe] flex items-center justify-center flex-shrink-0">
                    <cred.icon size={20} className="text-[#6366f1]" />
                  </div>
                  <span className="font-['Inter'] font-medium text-[16px] text-[#1a1a2e]">
                    {cred.text}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Portrait */}
          <div
            className={`w-full md:w-[55%] relative transition-all duration-700 ease-out ${
              isInView
                ? 'opacity-100 translate-x-0'
                : 'opacity-0 translate-x-10'
            }`}
            style={{ transitionDelay: '0.15s' }}
          >
            {/* Decorative circle */}
            <div
              className="absolute -top-10 -left-10 w-[300px] h-[300px] rounded-full bg-[#a5b4fc] opacity-30 -z-10"
              style={{ filter: 'blur(40px)' }}
            />
            <img
              src="/images/img-1.jpg"
              alt="Soumyadip Biswas - M.Sc Mathematics educator and mentor at Soumya's Mathematics Academy in Kankinara"
              className="w-full max-w-[480px] mx-auto rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.08)] object-cover"
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
