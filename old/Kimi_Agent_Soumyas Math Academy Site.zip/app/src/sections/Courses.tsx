import { useIntersectionObserver } from '@/hooks/useIntersectionObserver';
import { Check, Calculator, Atom, Leaf, type LucideIcon } from 'lucide-react';

interface Course {
  iconBg: string;
  icons: LucideIcon[];
  title: string;
  subtitle: string;
  subjects: string[];
}

const courses: Course[] = [
  {
    iconBg: '#dbeafe',
    icons: [Calculator, Atom],
    title: 'Classes VI - X',
    subtitle: 'West Bengal Board',
    subjects: ['Mathematics', 'Physics', 'Chemistry'],
  },
  {
    iconBg: '#ede9fe',
    icons: [Calculator, Leaf],
    title: 'Classes XI - XII',
    subtitle: 'West Bengal Board',
    subjects: ['Mathematics', 'Biology'],
  },
  {
    iconBg: '#d1fae5',
    icons: [Calculator],
    title: 'Classes X - XII',
    subtitle: 'ICSE & CBSE Boards',
    subjects: ['Mathematics'],
  },
];

function CourseIcon({ icons, bg }: { icons: LucideIcon[]; bg: string }) {
  if (icons.length === 1) {
    const Icon = icons[0];
    return (
      <div className="w-14 h-14 rounded-xl flex items-center justify-center" style={{ backgroundColor: bg }}>
        <Icon size={28} className="text-[#6366f1]" />
      </div>
    );
  }

  return (
    <div className="w-14 h-14 rounded-xl flex items-center justify-center gap-1" style={{ backgroundColor: bg }}>
      {icons.map((Icon, j) => (
        <Icon key={j} size={20} className="text-[#6366f1]" />
      ))}
    </div>
  );
}

export default function Courses() {
  const { ref: sectionRef, isInView } = useIntersectionObserver<HTMLElement>({
    threshold: 0.15,
  });

  return (
    <section
      id="courses"
      ref={sectionRef}
      className="w-full py-[120px] md:py-[120px] bg-[#f8fafc]"
    >
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Section Header */}
        <div className="mb-16">
          <p className="section-label mb-4">COURSES OFFERED</p>
          <h2 className="heading-2">Comprehensive Academic Programs</h2>
        </div>

        {/* Course Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, i) => (
            <div
              key={i}
              className={`bg-white rounded-[20px] p-10 border border-[#e2e8f0] transition-all duration-600 ease-out hover:shadow-[0_12px_40px_rgba(0,0,0,0.08)] hover:-translate-y-1 cursor-default group ${
                isInView
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-[50px]'
              }`}
              style={{ transitionDelay: `${i * 0.15}s` }}
            >
              {/* Icon */}
              <div className="mb-6">
                <CourseIcon icons={course.icons} bg={course.iconBg} />
              </div>

              {/* Title */}
              <h3 className="font-['Poppins'] font-semibold text-[22px] text-[#1a1a2e] mb-1">
                {course.title}
              </h3>
              <p className="font-['Inter'] text-[15px] text-[#6366f1] mb-6">
                {course.subtitle}
              </p>

              {/* Subjects */}
              <ul className="flex flex-col gap-3">
                {course.subjects.map((subject, j) => (
                  <li key={j} className="flex items-center gap-3">
                    <Check size={18} className="text-[#6366f1] flex-shrink-0" />
                    <span className="font-['Inter'] text-[16px] text-[#4a5568]">
                      {subject}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
