import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useIntersectionObserver } from '@/hooks/useIntersectionObserver';

gsap.registerPlugin(ScrollTrigger);

const subjects = [
  'ALGEBRA',
  'GEOMETRY',
  'CALCULUS',
  'TRIGONOMETRY',
  'STATISTICS',
  'ARITHMETIC',
];

const galleryImages = [
  { src: '/images/img-2.jpg', alt: 'Modern classroom with whiteboard and desks at Soumya\'s Mathematics Academy' },
  { src: '/images/img-4.jpg', alt: 'Students collaborating on mathematics problems in group study session' },
  { src: '/images/img-5.jpg', alt: 'Mathematics textbooks including Calculus, Trigonometry and Geometry' },
];

export default function Gallery() {
  const sectionRef = useRef<HTMLElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const { ref: imagesRef, isInView } = useIntersectionObserver<HTMLDivElement>({
    threshold: 0.15,
  });

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const cards = cardsRef.current.filter(Boolean) as HTMLDivElement[];
    if (cards.length === 0) return;

    // Position cards in a circle
    const radius = 400;
    const angleStep = 360 / subjects.length;

    cards.forEach((card, i) => {
      const rotationY = i * angleStep;
      gsap.set(card, {
        transform: `rotateY(${rotationY}deg) translateZ(${radius}px)`,
      });
    });

    // Set initial container tilt
    gsap.set(container, {
      transform: 'rotateX(-5deg) rotateY(0deg)',
    });

    // Create ScrollTrigger
    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: container,
        start: 'center center',
        end: '+=150%',
        pin: true,
        scrub: 1,
      },
    });

    // Container rotation
    tl.fromTo(
      container,
      { rotationY: 0 },
      { rotationY: -180, ease: 'none' },
      0
    );

    // Container tilt variation
    tl.fromTo(
      container,
      { rotationZ: 3, rotationX: 5 },
      { rotationZ: -3, rotationX: -5, ease: 'none' },
      0
    );

    // Cards fan out
    tl.fromTo(
      cards,
      { rotationZ: 20, rotationX: 10 },
      { rotationZ: -20, rotationX: -10, ease: 'none', stagger: 0.02 },
      0
    );

    return () => {
      tl.kill();
      ScrollTrigger.getAll().forEach((st) => st.kill());
    };
  }, []);

  return (
    <section ref={sectionRef} className="w-full bg-[#f8fafc] overflow-hidden">
      {/* Section Header */}
      <div className="pt-[120px] pb-[60px] text-center">
        <p className="section-label mb-4">OUR FOCUS AREAS</p>
        <h2 className="heading-2">
          Every Branch of Mathematics, Mastered
        </h2>
      </div>

      {/* 3D Carousel */}
      <div
        ref={containerRef}
        className="relative h-[400px] flex items-center justify-center"
        style={{
          perspective: 800,
          transformStyle: 'preserve-3d',
          overflow: 'hidden',
        }}
      >
        {subjects.map((subject, i) => (
          <div
            key={i}
            ref={(el) => { cardsRef.current[i] = el; }}
            className="carousel-card"
            style={{ transformStyle: 'preserve-3d' }}
          >
            {subject}
          </div>
        ))}
      </div>

      {/* Image Grid */}
      <div
        ref={imagesRef}
        className="max-w-[1200px] mx-auto px-6 pb-[120px] pt-[60px]"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {galleryImages.map((img, i) => (
            <div
              key={i}
              className={`overflow-hidden rounded-2xl transition-all duration-600 ease-out ${
                isInView
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-[30px]'
              }`}
              style={{ transitionDelay: `${i * 0.15}s` }}
            >
              <img
                src={img.src}
                alt={img.alt}
                className="w-full h-[240px] object-cover hover:scale-105 transition-transform duration-500"
                loading="lazy"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
