import { useEffect, useState } from 'react';

export default function Hero() {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative w-full min-h-[100dvh] bg-white overflow-hidden">
      {/* SVG Text Stroke Animation Background */}
      <div className="absolute inset-0 flex items-center justify-center" aria-hidden="true">
        <svg
          viewBox="0 0 200 86"
          className="w-full h-full max-w-[1400px]"
          preserveAspectRatio="xMidYMid meet"
        >
          <defs>
            <style>
              {`
                text {
                  fill: none;
                  stroke: #1a1a2e;
                  stroke-width: 0.5px;
                  stroke-linecap: round;
                }
                .master text, .mathematics text {
                  font-family: 'Poppins', sans-serif;
                  font-weight: 700;
                }
              `}
            </style>
          </defs>

          {/* Row 1 - MASTER at y=30 */}
          <g className="master">
            <text x="10" y="30" fontSize="30">
              <tspan className="master-tspan-m" dx="0">M</tspan>
              <tspan className="master-tspan-a" dx="8">A</tspan>
              <tspan className="master-tspan-s" dx="8">S</tspan>
              <tspan className="master-tspan-t" dx="8">T</tspan>
              <tspan className="master-tspan-e" dx="8">E</tspan>
              <tspan className="master-tspan-r" dx="8">R</tspan>
            </text>
          </g>

          {/* Row 1 - MATHEMATICS at y=30 (delayed) */}
          <g className="mathematics">
            <text x="10" y="30" fontSize="30">
              <tspan className="math-tspan-m1" dx="0">M</tspan>
              <tspan className="math-tspan-a1" dx="4">A</tspan>
              <tspan className="math-tspan-t1" dx="4">T</tspan>
              <tspan className="math-tspan-h" dx="4">H</tspan>
              <tspan className="math-tspan-e1" dx="4">E</tspan>
              <tspan className="math-tspan-m2" dx="4">M</tspan>
              <tspan className="math-tspan-a2" dx="4">A</tspan>
              <tspan className="math-tspan-t2" dx="4">T</tspan>
              <tspan className="math-tspan-i" dx="3">I</tspan>
              <tspan className="math-tspan-c" dx="3">C</tspan>
              <tspan className="math-tspan-s1" dx="4">S</tspan>
            </text>
          </g>

          {/* Row 2 - MASTER at y=70 */}
          <g className="master master-row2">
            <text x="10" y="70" fontSize="30">
              <tspan className="master-tspan-m" dx="0">M</tspan>
              <tspan className="master-tspan-a" dx="8">A</tspan>
              <tspan className="master-tspan-s" dx="8">S</tspan>
              <tspan className="master-tspan-t" dx="8">T</tspan>
              <tspan className="master-tspan-e" dx="8">E</tspan>
              <tspan className="master-tspan-r" dx="8">R</tspan>
            </text>
          </g>

          {/* Row 2 - MATHEMATICS at y=70 */}
          <g className="mathematics math-row2">
            <text x="10" y="70" fontSize="30">
              <tspan className="math-tspan-m1" dx="0">M</tspan>
              <tspan className="math-tspan-a1" dx="4">A</tspan>
              <tspan className="math-tspan-t1" dx="4">T</tspan>
              <tspan className="math-tspan-h" dx="4">H</tspan>
              <tspan className="math-tspan-e1" dx="4">E</tspan>
              <tspan className="math-tspan-m2" dx="4">M</tspan>
              <tspan className="math-tspan-a2" dx="4">A</tspan>
              <tspan className="math-tspan-t2" dx="4">T</tspan>
              <tspan className="math-tspan-i" dx="3">I</tspan>
              <tspan className="math-tspan-c" dx="3">C</tspan>
              <tspan className="math-tspan-s1" dx="4">S</tspan>
            </text>
          </g>
        </svg>
      </div>

      {/* Gradient overlay for readability */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'linear-gradient(to right, rgba(255,255,255,0.95) 0%, rgba(255,255,255,0.7) 40%, rgba(255,255,255,0) 70%)',
        }}
      />

      {/* Hero Content - bottom left */}
      <div className="relative z-10 flex flex-col justify-end min-h-[100dvh] max-w-[1200px] mx-auto px-6 pb-[100px] md:pb-[120px] pt-[100px]">
        <div className="max-w-[600px]">
          {/* Label */}
          <p
            className={`section-label mb-6 transition-all duration-700 ease-out ${
              loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
            style={{ transitionDelay: '0.3s' }}
          >
            M.SC MATHEMATICS · OFFLINE COACHING
          </p>

          {/* Headline */}
          <h1
            className={`heading-1 mb-6 transition-all duration-800 ease-out ${
              loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{
              transitionDelay: '0.6s',
              transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)',
            }}
          >
            Master Mathematics
            <br className="md:hidden" /> with Confidence
          </h1>

          {/* Subheadline */}
          <p
            className={`font-['Inter'] text-[18px] md:text-[20px] text-[#4a5568] max-w-[480px] mb-8 transition-all duration-700 ease-out ${
              loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '0.9s' }}
          >
            Professional coaching for WB Board, ICSE &amp; CBSE students. Classes VI to XII.
          </p>

          {/* CTA */}
          <div
            className={`transition-all duration-700 ease-out ${
              loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
            style={{ transitionDelay: '1.2s' }}
          >
            <button onClick={scrollToContact} className="btn-primary mb-5">
              Get Free Consultation
            </button>

            {/* Phone */}
            <p className="font-['Inter'] font-medium text-[16px] text-[#4a5568]">
              Call:{" "}
              <a
                href="tel:6291210836"
                className="text-[#6366f1] hover:text-[#4f46e5] transition-colors"
              >
                6291210836
              </a>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
